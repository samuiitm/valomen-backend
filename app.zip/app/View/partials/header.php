<!-- app/View/partials/header.php -->
<?php
$pageTitle = $pageTitle ?? 'Valomen.gg';
$pageCss   = $pageCss   ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap" rel="stylesheet">

    <!-- Assets sempre amb url() per ser portables -->
    <link rel="icon" type="image/png" href="<?= url('assets/icons/valomen_logo.ico') ?>">

    <script defer src="<?= url('js/main.js') ?>"></script>
    <link rel="stylesheet" href="<?= url('css/generic.css') ?>">

    <?php if ($pageCss): ?>
        <link rel="stylesheet" href="<?= url('css/' . htmlspecialchars($pageCss)) ?>">
    <?php endif; ?>
</head>

<body class="<?= !empty($_SESSION['edit_mode']) ? 'edit-mode' : '' ?>">
<header>
    <nav>
        <div class="logo">
            <a href="<?= url('') ?>">
                <img src="<?= url('assets/img/valomen_logo.webp') ?>" alt="Valomen.gg Logo">
                <span>Valomen.gg</span>
            </a>
        </div>

        <div class="nav-buttons">
            <ul class="nav-links">
                <li><a href="<?= url('') ?>">Home</a></li>
                <li><a href="<?= url('matches') ?>">Matches</a></li>
                <li><a href="<?= url('events') ?>">Events</a></li>
            </ul>

            <?php if (!empty($_SESSION['user_id'])): ?>
                <div class="user-menu">
                    <?php
                        // Si l'usuari té avatar, el mostrem. Si no, posem el per defecte.
                        $avatarFilename = $_SESSION['user_logo'] ?? null;

                        if (!empty($avatarFilename)) {
                            $safeAvatar = rawurlencode($avatarFilename);
                            $headerAvatarSrc = url('assets/img/user-avatars/' . $safeAvatar);
                        } else {
                            $headerAvatarSrc = url('assets/img/default-avatar.png');
                        }
                    ?>
                    <button id="userMenuBtn" class="user-avatar-btn">
                        <img src="<?= htmlspecialchars($headerAvatarSrc) ?>"
                             alt="User avatar"
                             onerror="this.onerror=null; this.src='<?= htmlspecialchars(url('assets/img/default-avatar.png')) ?>';">
                    </button>

                    <div class="user-dropdown" id="userDropdown">
                        <div class="user-dropdown-header">
                            <span class="user-name">
                                <?= htmlspecialchars($_SESSION['username']) ?>
                            </span>

                            <?php if (!empty($_SESSION['is_admin'])): ?>
                                <span class="user-role">Admin</span>
                            <?php endif; ?>
                        </div>

                        <a href="<?= url('profile') ?>" class="dropdown-item">Profile</a>
                        <a href="<?= url('my_predictions') ?>" class="dropdown-item">My predictions</a>

                        <?php if (!empty($_SESSION['is_admin'])): ?>
                            <a href="<?= url('') ?>?action=toggle_edit_mode"
                               class="dropdown-item edit-toggle <?= !empty($_SESSION['edit_mode']) ? 'on' : 'off' ?>">
                                <span class="toggle-label">Edit mode</span>
                                <span class="toggle-pill">
                                    <span class="toggle-knob"></span>
                                </span>
                                <span class="toggle-state">
                                    <?= !empty($_SESSION['edit_mode']) ? 'ON' : 'OFF' ?>
                                </span>
                            </a>

                            <a href="<?= url('admin') ?>" class="dropdown-item">Admin panel</a>
                        <?php endif; ?>

                        <a href="<?= url('logout') ?>" class="dropdown-item logout-item">Log out</a>
                    </div>
                </div>
            <?php else: ?>
                <a class="login-button" href="<?= url('login') ?>">Log in</a>
            <?php endif; ?>
        </div>
    </nav>
</header>