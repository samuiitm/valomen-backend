<?php
// config/mail.local.php

return [
    'GMAIL'    => 's.canadas@sapalomera.cat',
    'PASSWORD' => 'luyp kkjw uicu eikf',
];
