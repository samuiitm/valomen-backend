<?php
// config/oauth.local.php

return [
    'GOOGLE_CLIENT_ID'     => '754489083351-ld5qhvojrrg0gd46fkv1sulgnvqj0v19.apps.googleusercontent.com',
    'GOOGLE_CLIENT_SECRET' => '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',

    'GITHUB_CLIENT_ID'     => 'Ov23lizBGtAwVQghcuag',
    'GITHUB_CLIENT_SECRET' => '9c8d00cf70896b594ad5b519cfae45fdbbc4e8b6',
];